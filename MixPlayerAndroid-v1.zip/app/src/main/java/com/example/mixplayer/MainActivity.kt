package com.example.mixplayer

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

data class Track(val title: String, val artist: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MixPlayerApp() }
    }
}

@Composable
fun MixPlayerApp() {
    var selected by remember { mutableStateOf<Track?>(null) }
    var playing by remember { mutableStateOf(false) }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Color(0xFF6C4DFF),
            background = Color(0xFFF7F7FA)
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = Color(0xFFF7F7FA)) {
            if (selected == null) {
                HomeScreen { selected = it; playing = true }
            } else {
                PlayerScreen(
                    track = selected!!,
                    playing = playing,
                    onBack = { selected = null },
                    onToggle = { playing = !playing }
                )
            }
        }
    }
}

@Composable
fun HomeScreen(onTrackClick: (Track) -> Unit) {
    val tracks = listOf(
        Track("Midnight Drive", "MixPlayer Demo"),
        Track("Summer Lights", "MixPlayer Demo"),
        Track("Ocean Waves", "MixPlayer Demo"),
        Track("Night City", "MixPlayer Demo")
    )

    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Text("MixPlayer", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Text("Your music, simply.", color = Color.Gray)
        Spacer(Modifier.height(24.dp))
        Text("Your Library", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(10.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(tracks) { track ->
                Row(
                    Modifier.fillMaxWidth()
                        .background(Color.White, RoundedCornerShape(18.dp))
                        .clickable { onTrackClick(track) }
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier.size(54.dp).background(Color(0xFFE5E0FF), RoundedCornerShape(14.dp)),
                        contentAlignment = Alignment.Center
                    ) { Text("♪", style = MaterialTheme.typography.headlineSmall) }
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text(track.title, fontWeight = FontWeight.Bold)
                        Text(track.artist, color = Color.Gray)
                    }
                }
            }
        }
    }
}

@Composable
fun PlayerScreen(track: Track, playing: Boolean, onBack: () -> Unit, onToggle: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("‹", style = MaterialTheme.typography.headlineLarge, modifier = Modifier.clickable { onBack() })
            Spacer(Modifier.width(16.dp))
            Text("Now Playing", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }

        Spacer(Modifier.height(55.dp))
        Box(
            Modifier.size(280.dp).background(Color(0xFFE5E0FF), RoundedCornerShape(30.dp)),
            contentAlignment = Alignment.Center
        ) { Text("♪", style = MaterialTheme.typography.displayLarge) }

        Spacer(Modifier.height(30.dp))
        Text(track.title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(track.artist, color = Color.Gray)
        Spacer(Modifier.height(30.dp))
        Slider(value = 0.35f, onValueChange = {})
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("1:12", color = Color.Gray)
            Text("3:42", color = Color.Gray)
        }
        Spacer(Modifier.height(24.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("↶", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.width(30.dp))
            FilledIconButton(onClick = onToggle, modifier = Modifier.size(72.dp)) {
                Text(if (playing) "Ⅱ" else "▶", style = MaterialTheme.typography.headlineSmall)
            }
            Spacer(Modifier.width(30.dp))
            Text("↷", style = MaterialTheme.typography.headlineMedium)
        }
    }
}
